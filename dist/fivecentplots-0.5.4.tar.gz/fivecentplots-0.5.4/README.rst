Install latest release using:

pip install fivecentplots

Read the docs at:

https://endangeredoxen.github.io/fivecentplots
